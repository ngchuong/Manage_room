import React from 'react';
import './table.scss';

const Table = () => {
    return (
        <div>

        </div>
    );
}

export default Table;