import React from 'react';
import Login from './pages/login/login.js';
import Mainlayout from './mainlayout/mainlayout.js';

function App() {
  return (
    <div className="App">
      {/* <Login /> */}
      <Mainlayout />
    </div>
  );
}

export default App;
